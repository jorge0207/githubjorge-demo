var tareas = angular.module('tareas', []);
 
tareas.controller('mainCtrl', function($scope, $log, $filter){
 
    $scope.listado = [
          {
            "tarea": "comprar pendrive",
            "prioridad": "alta",
            "tipo": "personal"
          },
          {
            "tarea": "entregar práctica Drupal",
            "prioridad" : "normal",
            "tipo": "trabajo"
          },
          {
            "tarea": "felicitar cumple Javier",
            "prioridad" : "normal",
            "fecha": "21/03"
          },
          {
            "tarea": "renovar DNI",
            "prioridad": "alta",
            "tipo": "personal",
            "fecha": "1/04/2015"
          }
        ];
     
    $scope.anadirTarea = function() {
        var nueva_tarea = {
            "tarea" : $scope.nombreTarea,
            "tipo" : $scope.tipoTarea,
            "prioridad": $scope.prioridadTarea,
            "fecha" : $scope.fechaTarea
        };
        $scope.listado.unshift(nueva_tarea);
 
        //console.log($scope.listado);
    };  
 
    $scope.eliminarTarea = function(tarea){
        console.log("eliminando tarea " + tarea);
 
        _.remove($scope.listado, function(task) {
            return task.tarea === tarea;
        });
        console.log($scope.listado);
    };
 
});