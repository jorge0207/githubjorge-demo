A Pen created at CodePen.io. You can find this one at https://codepen.io/apedreroes/pen/rarBbZ.

 App para estudiar el comportamiento de las directivas de AngularJS